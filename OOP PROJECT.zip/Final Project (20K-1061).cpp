#include<iostream>
#include<fstream>
#include<string.h>
#include<time.h>
#include<conio.h>
#include<stdlib.h>
#include<windows.h>
using namespace std;


//// Flight Management System

	char karachi[10]="Karachi";
	char la[10]="Lahore";
	char multan[10]="Multan";
	char isl[10]="Islamabad";
	char f1[10]="AA-000";
	char f2[10]="AA-001";
	char f3[10]="AA-002";
	char f4[10]="AA-003";
class passenger{

	private:
		char name[10];
		static int occ;
		char cnic[10];
		int age;
		
	public:
		char flightno[10];
		static int pnr;
		int pnrr;
		int cost;
		
		passenger(char n[],char m[])
		{
			
    	int i ;
    		for(i=0;i<10;i++)
			{
				name[i]=n[i];
				cnic[i]=m[i];
			}
		
			book();
	
		}

	
	
			
		passenger(int a)
		{
			
    		for(int i=0;i<10;i++)
			{
				name[i]='x';
				cnic[i]='x';
			}
			occ--;
		}
		
		passenger()
		{
		
		}
		
		getdetails()
		{
			cout<<"\t\t\t\t\tEnter Flight Number: ";
			cin>>flightno;
			cout<<"\t\t\t\t\tEnter Name: ";
			cin>>name;												//  PASSENGER DETAILS
			cout<<"\t\t\t\t\tEnter Age: ";
			cin>>age;	
			cout<<"\t\t\t\t\tEnter CNIC: ";
			cin>>cnic;
		}
		
		int getpnr()
		{
			return pnr;
		}
		
	
		book()
		{
			pnrr=pnr;
			pnr++;
			getdetails();
			
			fstream a;
			a.open("Passenger.txt",ios::in|ios::out|ios::ate|ios::app|ios::binary);
																					 
			a.write((char*)this,sizeof(passenger));											//ENTERING THE PASSENGER DETAILS IN THE FILE
			a.close();
		}
		
		deleted()
		{
			int temp;
			char t[10];
			cout<<"\n\n\t\t\t\t\tEnter the PNR Number: ";
			cin>>temp;
			
			int f;
			passenger tem;
			fstream a,b;
			int i=0;
			b.open("Temp.txt",ios::in|ios::out|ios::app);
			a.open("Passenger.txt",ios::in|ios::out|ios::app);
			while(	a.read((char*)(&tem),sizeof(passenger)))			//DELETING THE FLIGHT DATA THROUGH PNR NO.
			{
				
				
				if (temp==tem.pnrr)
				{
							
					cout<<"\n\n\t\t\t\t\tFlight Deleted"<<endl;	
				}
			
			
				else
		
					b.write((char*)(&tem),sizeof(passenger));
					
			}
					a.close();
					b.close();
			remove("Passenger.txt");
			rename("Temp.txt","Passenger.txt");
			
		}
		
		
		friend class flights;
		edit()
		{
			int temp;
			char t[10];
			cout<<"\n\n\t\t\t\t\tEnter the PNR Number: ";
			cin>>temp;
			cout<<"\n\n\t\t\t\t\tEnter the New Flight Number: ";
			cin>>t;
			int f;
			passenger tem;
			fstream a;
		
			int i=0;
			a.open("Passenger.txt",ios::in|ios::out|ios::app);
			
			while(	a.read(reinterpret_cast<char*>(&tem),sizeof(passenger)))			
			{
				if (temp==tem.pnrr)
				{
						for(i=0;i<10;i++)								//through pnr no. new flight data is entered
			{
			
				tem.flightno[i]=t[i];
			}
		
					f= sizeof(tem);
					f*=-1;
					a.seekp(f,ios::cur);
					
					a.write((char*)&tem,sizeof(passenger));
				}
			}
			a.close();
		}
			
		friend fly(char a[]);
		dpass()
		{
			cout<<"\t\t\t\t\tPNR Number: "<<pnrr<<endl;
			cout<<"\t\t\t\t\tName: "<<name<<endl;								//DISPLAY OF TICKET
			cout<<"\t\t\t\t\tAge: "<<age<<endl;
			cout<<"\t\t\t\t\tCNIC: "<<cnic<<endl;
			
			
		}
		
};

class time{
	public:
		int hour;
		int min;
		
		time()
		{
			
		}
		
		time(int a, int b)
		{
			hour=a;
			min=b;
		}
		
		set(time a)
		{
			hour=a.hour;
			min=a.min;
		}
		
		show()
		{
			cout<<hour<<":"<<min<<endl;
		}
		friend class flights;
		
			time operator -(time a)
		{
			time b;
			b.hour= a.hour-this->hour;
			b.min= a.min-this->min;
			return b;
			
		}
};

class flights{
	char flight_number[10];
	char to[10];
	char from[10];
	friend class time;
	class time takeoff;
	class time land;
	static int seatno;
	int seats;
	int filled;
	friend class passenger;	
	
	public:
		passenger pass;	
		int price;
		friend fly(char a[]);		
    setnum(char a[10])
    {
    	int i;
    		for(i=0;i<10;i++)
			{
				flight_number[i]=a[i];
			}
			
			cout<<flight_number;
	
	}
	
		flights(){
			filled=0;
			seats=50;
		}
	
		flights(char fn[10], char t[10], char f[10], int tfh,int tfm, int lh,int lm,int p):takeoff(tfh,tfm),land(lh,lm)
		{
			filled=0;
			seats=50;
			setnum(fn);									//flights data input
			setfrom(f);
			setto(t);
			price=p;
			file(); 
		}
		
		file()
		{
			fstream data;
			data.open("Flights.txt",ios::in|ios::out|ios::ate|ios::app|ios::binary);
   
    
        data.write((char*)this,sizeof(flights));								//data of flights entered in file

			data.close();    
    
		}
			dflight()
		{

			cout<<"\t\t\t\t\tFlight Number: "<<flight_number<<endl;
			cout<<"\t\t\t\t\tTo: "<<to<<endl;
			cout<<"\t\t\t\t\tFrom: "<<from<<endl;
			cout<<"\t\t\t\t\tTake Off Time: "<<takeoff.hour;
			cout<<":"<<takeoff.min<<endl;
			cout<<"\t\t\t\t\tLanding Time: "<<land.hour;								//FLIGHT DETAILS
			cout<<":"<<land.min<<endl;
			cout<<"\t\t\t\t\tDuration: "<<land.hour-takeoff.hour;
			cout<<":"<<land.min-takeoff.min<<endl;
			cout<<"\t\t\t\t\tTicket Cost: "<<price<<endl;
			cout<<endl<<endl;
		}
		
		check(char a[], char b[])
		{
			int i,j=0;
			
			for(i=0;i<10;i++)
			{
				if (a[i]==b[i]&&i==5)
				{
					return 0;
				}
			}
			return 1;
		}
	
		friend fly();
		display()
		{
			flights pers;
			fstream file;
			file.open("Flights.txt",ios::in|ios::out|ios::ate|ios::app|ios::binary);
 
    file.seekg(0);

    file.read(reinterpret_cast<char*>(&pers),sizeof(pers));										//Displaying the flights data from file in console
																		
    while(!file.eof())				
    {
           cout<<"\n\n\t\t\t\t\t  Flights Avalible\n";
          pers.dflight();									
          file.read((char*)&pers,sizeof(pers));

    }
    
    file.close();


		}
		
		
    setto(char a[10])
    {
    	int i;
    		for(i=0;i<10;i++)
			{
				to[i]=a[i];
			}
			
			cout<<to;
	
	}
	

	
fly(char a[])
{
		
		flights pers;
			fstream file;
			file.open("Flights.txt",ios::in|ios::out|ios::ate|ios::app|ios::binary);
 
    file.seekg(0);

    

    while(file.read((char*)&pers,sizeof(pers)))
    {
			if (pers.check(a,pers.flight_number)==0)
			{
				pers.dflight();
					
			}
			
    }
    
    
    
    
}
	
    setfrom(char a[10])
    {
    	int i;
    		for(i=0;i<10;i++)
			{
				from[i]=a[i];
			}
			
			cout<<from;
	
	}
	
		show(){
			
				passenger pers;
			fstream file;
			file.open("Passenger.txt",ios::in|ios::out|ios::app);
 
		    file.seekg(0);

   
    while( file.read((char*)&pers,sizeof(pers)))
    {
         
          cout<<"\n\n\t\t\t\t\tPassengers\n";							// Showing FINAL PASSENGER LIST
          pers.dpass();
          fly(pers.flightno);
    }
    
    file.close();

		
			
		}
		
	
};


int passenger::pnr(0);


void text_animation(string a);
void text_animation(string a){

	int i;
	long double j;
	
	for(i=0;a[i]!='\0';i++){

		for(j=0;j<10000000;j++);
			cout<<a[i];
	}
}

int main()
	
	{
	
	{
	system("Color FC");
	
	cout <<"\n\n\n\n\n";
	cout <<"\t\t\t\t______________________________________________________\n\n\n";
	text_animation("\t\t\t\t\t~~ Welcome To Flight Management System ~~\n\n" );
	cout <<"\t\t\t\t______________________________________________________\n";
	cout<<endl;
    text_animation("\t\t\t\t\t Book your Flight tickets here !\n" );
    cout <<"\t\t\t\t______________________________________________________\n";
    text_animation("\t\t\t\tDue to Covid-19 all International Flights are canceled\n\t\t\t\t\tonly Domestic Flights are avalible.\n");
   cout <<"\t\t\t\t______________________________________________________\n\n\n";
 	cout<<"\t\t\t\tPress any key to continue.... \n";
	getch();
	}
	
	system("CLS");
	system("Color F5");
		
	
	flights a(f1,isl ,karachi,10,30,12,30,10000);
	cout<<"\t\t";
	flights b(f2,multan,karachi,8,30,10,30,15000);
	cout<<"\t\t";
	flights c(f3,karachi,multan,12,30,14,50,25000);
	cout<<"\t\t";
	flights d(f4,karachi,la,1,30,2,50,17000);
	cout<<endl;
	a.display();
	int ans,p;
	
	getch();
		
	do
	{ 
		system("pause");
		system("CLS");
		system("Color F1");
		cout<<endl<<endl<<endl<<endl<<endl;
		cout<<"\t\t\t\t\tWhat do you want to do?"<<endl;
		cout<<"\t\t\t\t\t1-Book a Flight?"<<endl;
		cout<<"\t\t\t\t\t2-Cancel a Flight?"<<endl;
		cout<<"\t\t\t\t\t3-Reschedule"<<endl;
		cout<<"\t\t\t\t\t4-Show Passangers"<<endl;
		cout<<"\t\t\t\t\t5-Exit"<<endl;
		cout<< "\n\t\t\t\t\tEnter Your Choice: ";
		cin>>ans;
		cout<<endl<<endl;
		
		if (ans==1)
		{
			p=a.pass.getpnr();
			a.pass.book();
			cout<<"\t\t\t\t\tTickets Are Booked Successfully";
			cout<<endl<<endl;
		}
		else if(ans==2)
		{
		a.pass.deleted();	
		
		
		} 
		
		else if(ans==3)
		
		{
	
			a.pass.edit();
			cout<<"\n\t\t\t\t\t Flight Got Reschedule\n";
		}
		else if(ans==4)
		{ 	cout<<endl;
			cout<<"\t\t\t\t\t~Sanjana Airlines~\n";
			a.show();
			
		}
	}while(ans!=5);
	
	
	
	system("cls");
	system("color f0");
	cout<<"\n\n\n\n\n\n\t\t\t\t\t";
	text_animation("Created By Raza Abidi");
	cout<<endl<<endl;
	//system("pause");
	remove("Passenger.txt");
	remove("Flights.txt");
	remove("Temp.txt");
}

